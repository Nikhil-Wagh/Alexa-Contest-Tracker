/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/

'use strict';

const Alexa = require('alexa-sdk');

const APP_ID = "YOUR_SKILL_ID";  // TODO replace with your app ID (OPTIONAL).

const handlers = {
	'LaunchRequest': function () {
		this.emit(':askWithCard', "Welcome", "How may I help you today", YOUR_SKILL_NAME, removeSSML("Welcome"));
	},
	'GetNewFactIntent': function () {
		this.emit('GetFact');
	},
	'YOUR_CUSTOM_INTENT': function () {
		// Use this.t() to get corresponding language data
	},
	'AMAZON.HelpIntent': function () {
		const speechOutput = this.t('HELP_MESSAGE');
		const reprompt = this.t('HELP_MESSAGE');
		this.emit(':ask', speechOutput, reprompt);
	},
	'AMAZON.CancelIntent': function () {
		this.emit(':tell', this.t('STOP_MESSAGE'));
	},
	'AMAZON.StopIntent': function () {
		this.emit(':tell', this.t('STOP_MESSAGE'));
	},
	'SessionEndedRequest': function () {
		this.emit(':tell', this.t('STOP_MESSAGE'));
	}
};

function removeSSML (s) {
	return s.replace(/<\/?[^>]+(>|$)/g, "");
}

exports.handler = (event, context) => {
	const alexa = Alexa.handler(event, context);
	alexa.APP_ID = APP_ID;
	// To enable string internationalization (i18n) features, set a resources object.
	alexa.resources = languageStrings;
	alexa.registerHandlers(handlers);
	alexa.execute();
};